package com.hu.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import com.hu.dao.UserDao;
import com.hu.entity.User;

@Service
public class UserService {
	
	@Resource
	private UserDao userDao;
	
	// 登录功能
	public boolean signin(String username, String password) {
        User user = userDao.getUser(username, password);
        if (user == null) {
            return false;
        }else{
            return true;
        }
    }

	// 注册功能
	public void register(String username, String password, String email) {
		userDao.signIn(username,password,email);
	}

	// 管理员查询所有用户
	public List<User> list() {
		return userDao.list();
	}

	// 管理员删除用户操作
	public void delete(Integer userId) {
		userDao.delete(userId);
	}

	// 根据id查找用户
	public User getById(Integer userId) {
		return userDao.getById(userId);
	}

	// 管理员更新用户
	public void update(User user) {
		userDao.update(user);
	}

	// 根据username查找用户
	public User findByName(String username) {
		return userDao.findByName(username);
	}
}
