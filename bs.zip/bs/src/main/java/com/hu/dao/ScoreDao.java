package com.hu.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.hu.entity.Score;
/**
 * score表的实体类
 * @author 10851
 *
 */
@Repository
public interface ScoreDao {

	List<Score> list(@Param("csid") Integer csid);

	Score findBySid(@Param("sid") Integer sid);

	int findFirstSid(@Param("csid") Integer csid);

	int findLastSid(@Param("csid") Integer csid);

	Score findPrevious(@Param("sid") Integer sid, @Param("csid") Integer csid);

	Score findNext(@Param("sid") Integer sid, @Param("csid") Integer csid);

	String findLocalBySid(@Param("sid") Integer sid);

	void delete(@Param("sid") Integer sid);

	void update(Score score);

	void updateLocal(Score score);

	void add(Score score);

	List<Score> search(@Param("searchtext") String searchtext);

}
