package com.hu.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hu.entity.Article;
import com.hu.entity.Audio;
import com.hu.entity.Discuss;
import com.hu.entity.Score;
import com.hu.entity.Video;
import com.hu.service.ArticleService;
import com.hu.service.AudioService;
import com.hu.service.DiscussService;
import com.hu.service.ScoreService;
import com.hu.service.VideoService;
/**
 * 二级分类的控制器
 * @author 10851
 *
 */
@Controller
public class CategoryController {

	@Resource
	private ArticleService articleService;
	@Resource
	private VideoService videoService;
	@Resource
	private ScoreService scoreService;
	@Resource
	private AudioService audioService;
	@Resource
	private DiscussService discussService;
	
	@RequestMapping("/discuss")
	public String discuss(ModelMap map, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		Integer pageSize = 10;
		PageHelper.startPage(pageNo, pageSize);
		List<Discuss> discussList = discussService.list();
		PageInfo<Discuss> pageInfo = new PageInfo<Discuss>(discussList);
		map.addAttribute("pageInfo", pageInfo);
//		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
//      String date = df.format(new Date());// new Date()为获取当前系统时间
		return "views/pagination/discusslist";
	}
	
	// 搜索曲谱
	@RequestMapping("/hu/search")
	public String search(ModelMap map,@RequestParam("searchtext") String searchtext, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		Integer pageSizeThree=4;//每页显示记录数
        //分页查询
        PageHelper.startPage(pageNo, pageSizeThree);
        List<Score> scoreList = scoreService.search(searchtext);
        
        PageInfo<Score> pageInfo =new PageInfo<Score>(scoreList);
        map.addAttribute("pageInfo", pageInfo);
        map.addAttribute("searchtext", searchtext);
//        map.addAttribute("localcsname", "流行乐曲");
//        map.addAttribute("csid", 3);
		return "views/pagination/searchlist";
	}
	
	// 根据id查找所在分类下内容并分页
	@RequestMapping("/column/{csid}/{csname}")
	public String pageList(@PathVariable("csid") Integer csid, @PathVariable("csname") String csname, ModelMap map, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo){
        
        switch(csid) {
	        case 1:
	        	Integer pageSize=6;//每页显示记录数
	            //分页查询
	            PageHelper.startPage(pageNo, pageSize);
	            List<Article> articleList = articleService.list(csid);
	            PageInfo<Article> pageInfo=new PageInfo<Article>(articleList);
	            map.addAttribute("pageInfo", pageInfo);
	            map.addAttribute("localcsname", csname);
	            map.addAttribute("csid", csid);
//	            System.out.println("---------------");
//	            System.out.println(pageInfo.getList());
//	            for(Article l : pageInfo.getList()) {
//	            	System.out.println(l.getTitle());
//	            }
	        	return "views/pagination/bfknowledge";
	        case 2:
	        	Integer pageSizeTwo=4;//每页显示记录数
	            //分页查询
	            PageHelper.startPage(pageNo, pageSizeTwo);
	            List<Video> videoList = videoService.list(csid);//获取所有用户信
//	            System.out.println("---"+videoList);
	            
	            PageInfo<Video> pageInfoTwo =new PageInfo<Video>(videoList);
	            map.addAttribute("pageInfo", pageInfoTwo);
	            map.addAttribute("localcsname", csname);
	            map.addAttribute("csid", csid);
	        	return "views/pagination/introcourse";
	        case 3:
	        	Integer pageSizeSix=4;//每页显示记录数
	            //分页查询
	            PageHelper.startPage(pageNo, pageSizeSix);
	            List<Audio> audioList = audioService.list(csid);
//	            System.out.println("---"+videoList);
	            
	            PageInfo<Audio> pageInfoSix =new PageInfo<Audio>(audioList);
	            map.addAttribute("pageInfo", pageInfoSix);
	            map.addAttribute("localcsname", csname);
	            map.addAttribute("csid", csid);
	        	return "views/pagination/audiolist";

	        case 4:
	        	Integer pageSizeFive=4;//每页显示记录数
	            //分页查询
	            PageHelper.startPage(pageNo, pageSizeFive);
	            List<Video> videoListtwo = videoService.list(csid);
//	            System.out.println("---"+videoList);
	            
	            PageInfo<Video> pageInfoFive =new PageInfo<Video>(videoListtwo);
	            map.addAttribute("pageInfo", pageInfoFive);
	            map.addAttribute("localcsname", csname);
	            map.addAttribute("csid", csid);
	        	return "views/pagination/introcourse";
	        case 5:
	        	Integer pageSizeThree=4;//每页显示记录数
	            //分页查询
	            PageHelper.startPage(pageNo, pageSizeThree);
	            List<Score> scoreList = scoreService.list(csid);
//	            System.out.println("---"+scoreList);
	            
	            PageInfo<Score> pageInfoThree =new PageInfo<Score>(scoreList);
	            map.addAttribute("pageInfo", pageInfoThree);
	            map.addAttribute("localcsname", csname);
	            map.addAttribute("csid", csid);
	        	return "views/pagination/scorelist";
	        case 6:
	        	Integer pageSizeFour=4;//每页显示记录数
	            //分页查询
	            PageHelper.startPage(pageNo, pageSizeFour);
	            List<Score> scoreListtwo = scoreService.list(csid);
	            
	            PageInfo<Score> pageInfoFour =new PageInfo<Score>(scoreListtwo);
	            map.addAttribute("pageInfo", pageInfoFour);
	            map.addAttribute("localcsname", csname);
	            map.addAttribute("csid", csid);
	        	return "views/pagination/scorelist";
	        default:
	        	return "views/pagination/bfknowledge";	
        }
    }

}
