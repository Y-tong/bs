package com.hu.service;

import java.util.List;

import javax.annotation.Resource;
import com.hu.dao.DiscussDao;
import com.hu.entity.Discuss;

import org.springframework.stereotype.Service;
/**
 * 讨论区的Service
 * @author 10851
 *
 */
@Service
public class DiscussService {
	
	@Resource
	private DiscussDao discussDao;

	// 查询所有帖子
	public List<Discuss> list() {
		return discussDao.list();
	}

	// 发帖
	public void release(String title, String content, String username, String date) {
		discussDao.release(title,content,username,date);
	}

	// 根据id查找帖子
	public Discuss findDiscussById(Integer disid) {
		return discussDao.findDiscussById(disid);
	}

	// 管理员删除帖子
	public void delete(Integer disid) {
		discussDao.delete(disid);
	}
	
	
}
