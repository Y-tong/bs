package com.hu.controller;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.hu.entity.Article;
import com.hu.entity.Category;
import com.hu.entity.CategorySecond;
import com.hu.entity.User;
import com.hu.service.ArticleService;
import com.hu.service.CategoryService;
import com.hu.service.UserService;
//import com.opensymphony.xwork2.ActionContext;

/**
 * 用户Controller
 * 用来处理用户登录，注册之类的
 * @author 10851
 *
 */
@Controller
public class UserController {
	
	@Resource
	private UserService userService;
	
	@Resource
	private CategoryService categoryService;
	
	@Resource
	private ArticleService articleService;
	
	// 主页面加载
	@RequestMapping("/")
    public String index(HttpSession httpSession, Model model) {
		List<Category> categorys = categoryService.getCategorys();
//		System.out.println("------------------");
//		for (Category category : categorys) {
//            System.out.println(category.getCname());
//            for(CategorySecond categorysecond : category.getCategoryseconds()) {
//            	System.out.println(categorysecond.getCsname());
//            }
//        }
//        model.addAttribute("categorys", categorys);
		//Session储存作用域广，查一次之后就不用查了
		httpSession.setAttribute("categorys", categorys); 
		//查一下最新，最热文章
		List<Article> mosthotarticles = articleService.findMostHot();
		model.addAttribute("mosthotarticles", mosthotarticles);
		
		List<Article> mostnewarticles = articleService.findMostNew();
		model.addAttribute("mostnewarticles", mostnewarticles);
//		request.setAttribute("categorys", categorys);
		return "views/index";
    }
	
	// 转到注册界面
	@RequestMapping("/hu/signup")
	public String login(Model model) {
		return "views/login";
	}
	
	// 转到登录界面
	@RequestMapping("/hu/signin")
	public String signin(Model model) {
		return "views/signin";
	}
	
	// 登录功能
	@RequestMapping(value = "hu/dologin", method = RequestMethod.POST)
    public String doLogin(HttpServletRequest request, Model model,@ModelAttribute User user) {
//      System.out.println("------------------");
//		System.out.println("user.getUsername():" + user.getUserName() + ";user.getPassword():" + user.getPassword());
        if (userService.signin(user.getUserName(), user.getPassword())) {
            request.getSession().setAttribute("user", user);
            model.addAttribute("user", user);
            return "redirect:/";
        } else {
            model.addAttribute("error", "用户名或密码错误");
            return "views/signin";
        }
    }
	
	// 登录验证用户名是否重复
	@RequestMapping(value = "hu/userfind")
    public void userfind(HttpServletRequest request,HttpServletResponse response, Model model, @RequestParam(value="username",required=true)String username) throws IOException {
		User existUser = userService.findByName(username);
		response.setContentType("text/html;charset=UTF-8");
		// 判断
		if (existUser != null) {
			// 查询到该用户:用户名已经存在
			response.getWriter().println("<font color='red'>用户名已经存在</font>");
		} else {
			// 没查询到该用户:用户名可以使用
			response.getWriter().println("<font color='green'>用户名可以使用</font>");
		}
	}
	
	// 注册功能
	@RequestMapping(value = "hu/register", method = RequestMethod.POST)
	public String register(HttpServletRequest request, Model model,@ModelAttribute User user) {
//		System.out.println("------------------");
//		System.out.println("user.getUsername():" + user.getUserName() + ";user.getPassword():" + user.getPassword()+user.getEmail());
		userService.register(user.getUserName(), user.getPassword(), user.getEmail());
		model.addAttribute("success", "注册成功");
		return "views/login";
	}
	
	
	//表单提交测试
	@RequestMapping(value="/hu/dologintest", method=RequestMethod.POST)
	private String doSave(@ModelAttribute User user, HttpSession session){
        System.out.println(user.getUserName());
        session.setAttribute("user", user);
        
		return "redirect:/user/view/"+user.getUserId();
	}
	// 测试
	@RequestMapping(value="/user/view/{userId}", method=RequestMethod.GET)
	private String viewUser(@PathVariable("userId") String userId){
		return "/views/index";
	}

}
