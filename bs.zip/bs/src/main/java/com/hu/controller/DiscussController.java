package com.hu.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hu.entity.Discuss;
import com.hu.entity.User;
import com.hu.service.DiscussService;

@Controller
public class DiscussController {

	@Resource
	private DiscussService discussService;
	
	// 发帖功能
	@RequestMapping(value = "discuss/release/{userName}", method = RequestMethod.POST)
	public String release(HttpServletRequest request, @PathVariable("userName") String userName, Model model,@ModelAttribute Discuss discuss) {
//		System.out.println("------------------");
//		System.out.println("user.getUsername():" + user.getUserName() + ";user.getPassword():" + user.getPassword()+user.getEmail());
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		String date = df.format(new Date());// new Date()为获取当前系统时间
		discussService.release(discuss.getTitle(),discuss.getContent(),userName,date);
		return "redirect:/discuss";
	}
	
	// 匿名发帖功能
	@RequestMapping(value = "discuss/release", method = RequestMethod.POST)
	public String releasetwo(HttpServletRequest request, Model model,@ModelAttribute Discuss discuss) {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		String date = df.format(new Date());// new Date()为获取当前系统时间
		discuss.setAuthor("匿名");
		discussService.release(discuss.getTitle(),discuss.getContent(),discuss.getAuthor(),date);
		return "redirect:/discuss";
	}
}
