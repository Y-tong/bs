package com.hu.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.hu.entity.Article;

@Repository
public interface ArticleDao {

	List<Article> list(@Param("csid") Integer csid);

	Article findByAid(@Param("aid") Integer aid);

	Article findPrevious(@Param("aid") Integer aid);

	Article findNext(@Param("aid") Integer aid);

	int findFirstAid();

	int findLastAid();

	List<Article> findMostHot();

	List<Article> findMostNew();

	void delete(@Param("aid") Integer aid);

	void update(Article article);

	void add(Article article);

}
