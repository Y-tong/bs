package com.hu.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hu.dao.ArticleDao;
import com.hu.entity.Article;

// 文章模块的Service
@Service
public class ArticleService {

	@Resource
	private ArticleDao articleDao;

	// 查找全部文章
	public List<Article> list(int csid) {
		List<Article> article = articleDao.list(csid);
		return article;
	}

	//根据aid查找文章内容
	public Article findByAid(Integer aid) {
		return articleDao.findByAid(aid);
	}

	//查找前一篇文章
	public Article findPrevious(Integer aid) {
		return articleDao.findPrevious(aid);
	}

	//查找后一篇文章
	public Article findNext(Integer aid) {
		return articleDao.findNext(aid);
	}

	//查找第一篇文章的id
	public int findFirstAid() {
		return articleDao.findFirstAid();
	}

	// 查找第二篇文章id
	public int findLastAid() {
		return articleDao.findLastAid();
	}

	public List<Article> findMostHot() {
		return articleDao.findMostHot();
	}

	public List<Article> findMostNew() {
		// TODO Auto-generated method stub
		return articleDao.findMostNew();
	}

	// 管理员删除文章
	public void delete(Integer aid) {
		articleDao.delete(aid);
	}

	// 管理员更改文章
	public void update(Article article) {
		articleDao.update(article);
	}

	// 管理员添加文章
	public void add(Article article) {
		articleDao.add(article);
	}
	
}
