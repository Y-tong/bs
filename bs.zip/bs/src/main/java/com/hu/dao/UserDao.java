package com.hu.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.hu.entity.User;

@Repository
public interface UserDao {
	public User getUser(@Param("username") String username, @Param("password") String password);
	public void signIn(@Param("username")String username, @Param("password") String password, @Param("email") String email);
	public List<User> list();
	public void delete(@Param("userId") Integer userId);
	public User getById(@Param("userId") Integer userId);
	public void update(User user);
	public User findByName(@Param("username")String username);
}
