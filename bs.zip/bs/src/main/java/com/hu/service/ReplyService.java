package com.hu.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hu.dao.ReplyDao;
import com.hu.entity.Reply;

/**
 * 回复的service
 * @author 10851
 *
 */
@Service
public class ReplyService {

	@Resource
	private ReplyDao replyDao;

	// 根据disid查找回复列表
	public List<Reply> list(Integer disid) {
		return replyDao.list(disid);
	}

	// 回复的方法
	public void reply(Reply reply) {
		replyDao.reply(reply);
	}

	// 管理员删除回复
	public void delete(Integer rid) {
		replyDao.delete(rid);
	}

	// 删除帖子时，先删评论
	public void deleteByDisid(Integer disid) {
		replyDao.deleteByDisid(disid);
	}

	
}
