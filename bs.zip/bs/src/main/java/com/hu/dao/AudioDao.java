package com.hu.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.hu.entity.Audio;

/**
 * 音频的Dao
 * @author 10851
 *
 */
@Repository
public interface AudioDao {

	List<Audio> list(@Param("csid") Integer csid);

	void delete(@Param("auid") Integer auid);

	Audio findByAuid(@Param("auid") Integer auid);

	void updateLocal(Audio audio);

	void update(Audio audio);

	String findLocalByAuid(@Param("auid") Integer auid);

	void add(Audio audio);

}
