package com.hu.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.hu.entity.Admin;

/**
 * 管理员的Dao
 * @author 10851
 *
 */
@Repository
public interface AdminDao {

	Admin getUser(@Param("username") String username,@Param("password") String password);

}
