package com.hu.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hu.entity.Article;
import com.hu.service.ArticleService;

@Controller
public class ArticleController {

	@Resource
    private ArticleService articleService;

	// 文章查看全文
	@RequestMapping("/content")
	public String ArtcileContent(Model model, @RequestParam(value="aid",required=true)Integer aid) {
		Article article = articleService.findByAid(aid);
//		System.out.println("--------"+article.getAid());
		int isFirst = articleService.findFirstAid();
		
		if(article.getAid() == isFirst) {
			model.addAttribute("isfirst", 1);
		}
		int isLast = articleService.findLastAid();
		if(article.getAid() == isLast) {
			model.addAttribute("islast", 1);
		}
//		System.out.println("-----------"+article.getAid()+"--"+isFirst+isLast);
		model.addAttribute("article", article);
		return "views/content/knowledgecontent";
	}
	
	// 竹笛入门分页中查看上一篇
	@RequestMapping("/content/previous")
	public String PreviousArtcileContent(Model model, @RequestParam(value="aid",required=true)Integer aid) {
		Article article = articleService.findPrevious(aid);
//		System.out.println("--------"+article.getAid());
		model.addAttribute("article", article);
		int isFirst = articleService.findFirstAid();
		if(article.getAid() == isFirst) {
			model.addAttribute("isfirst", 1);
		}
		int isLast = articleService.findLastAid();
		if(article.getAid() == isLast) {
			model.addAttribute("islast", 1);
		}
		return "views/content/knowledgecontent";
	}
	
	// 竹笛入门分页中查看下一篇
	@RequestMapping("/content/next")
	public String NextArtcileContent(Model model, @RequestParam(value="aid",required=true)Integer aid) {
		Article article = articleService.findNext(aid);
//		System.out.println("--------"+article.getContent());
		model.addAttribute("article", article);
		int isFirst = articleService.findFirstAid();
		if(article.getAid() == isFirst) {
			model.addAttribute("isfirst", 1);
		}
		int isLast = articleService.findLastAid();
		if(article.getAid() == isLast) {
			model.addAttribute("islast", 1);
		}
		return "views/content/knowledgecontent";
	}
}
