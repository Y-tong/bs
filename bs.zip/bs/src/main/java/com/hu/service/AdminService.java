package com.hu.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hu.dao.AdminDao;
import com.hu.entity.Admin;
import com.hu.entity.User;

/**
 * Admin的Service
 * @author 10851
 *
 */
@Service
public class AdminService {

	@Resource
	private AdminDao adminDao;

	public boolean signin(String username, String password) {
		Admin user = adminDao.getUser(username, password);
        if (user == null) {
            return false;
        }else{
            return true;
        }
	}
	
}
