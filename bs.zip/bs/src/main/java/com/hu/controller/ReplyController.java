package com.hu.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hu.entity.Discuss;
import com.hu.entity.Reply;
import com.hu.service.DiscussService;
import com.hu.service.ReplyService;
/**
 * 回复的controller
 * @author 10851
 *
 */
@Controller
public class ReplyController {

	@Resource
	private ReplyService replyService;
	@Resource
	private DiscussService discussService;
	
	// 帖子回复页面
	@RequestMapping("/discuss/reply/{disid}")
	public String discusscontent(@PathVariable("disid") Integer disid, ModelMap map, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		Integer pageSize = 10;
		PageHelper.startPage(pageNo, pageSize);
		List<Reply> replyList = replyService.list(disid);
		PageInfo<Reply> pageInfo = new PageInfo<Reply>(replyList);
		map.addAttribute("pageInfo", pageInfo);
//		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
//      String date = df.format(new Date());// new Date()为获取当前系统时间
		Discuss discuss = discussService.findDiscussById(disid);
		map.addAttribute("discuss", discuss);
		map.addAttribute("disid", disid);
		return "views/content/discusscontent";
	}
	
	// 回复功能
	@RequestMapping(value = "discuss/reply/release/{disid}/{userName}", method = RequestMethod.POST)
	public String reply(HttpServletRequest request, @PathVariable("disid") Integer disid, @PathVariable("userName") String userName, Model model,@ModelAttribute Reply reply) {
//			System.out.println("------------------");
//			System.out.println("user.getUsername():" + user.getUserName() + ";user.getPassword():" + user.getPassword()+user.getEmail());
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		String date = df.format(new Date());// new Date()为获取当前系统时间
		reply.setDisid(disid);
		reply.setAuthor(userName);
		reply.setDate(date);
		replyService.reply(reply);
		return "redirect:/discuss/reply/"+disid;
	}
	
	// 匿名回复功能
	@RequestMapping(value = "discuss/reply/release/{disid}", method = RequestMethod.POST)
	public String reply(HttpServletRequest request, @PathVariable("disid") Integer disid, Model model,@ModelAttribute Reply reply) {
//				System.out.println("------------------");
//				System.out.println("user.getUsername():" + user.getUserName() + ";user.getPassword():" + user.getPassword()+user.getEmail());
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		String date = df.format(new Date());// new Date()为获取当前系统时间
		reply.setDisid(disid);
		reply.setAuthor("匿名");
		reply.setDate(date);
		replyService.reply(reply);
		return "redirect:/discuss/reply/"+disid;
	}
}
