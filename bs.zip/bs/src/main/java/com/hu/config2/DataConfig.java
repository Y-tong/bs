package com.hu.config2;
//package com.hu.config;
//
//import org.apache.commons.dbcp.BasicDataSource;
//import org.mybatis.spring.SqlSessionFactoryBean;
//import org.mybatis.spring.annotation.MapperScan;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.PropertySource;
//import org.springframework.core.env.Environment;
//import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
//import org.springframework.core.io.support.ResourcePatternResolver;
//
//import javax.sql.DataSource;
//
//@Configuration
////使用@MapperScan来扫描注册mybatis数据库接口类，其中basePackages属性表明接口类所在的包
//@MapperScan(basePackages = "com.hu.mapper")
//@PropertySource("classpath:jdbc.properties")
//public class DataConfig
//{
//    @Autowired
//    private Environment environment;
//
//    /**
//     * 使用数据库链接池配置数据源
//     */
//    @Bean
//    public BasicDataSource dataSource()
//    {
//        BasicDataSource ds = new BasicDataSource();
//        ds.setDriverClassName(environment.getProperty("jdbc.driver"));
//        ds.setUrl(environment.getProperty("jdbc.url"));
//        ds.setUsername(environment.getProperty("jdbc.username"));
//        ds.setPassword(environment.getProperty("jdbc.password"));
//        //初始化连接大小
//        ds.setInitialSize(5);
//        //初始化连接池数量
//        ds.setMaxActive(10);
//        return ds;
//    }
//
//    /**
//     * 声明mybatis的session工厂
//     * @return
//     * @throws Exception
//     */
//    @Bean
//    public SqlSessionFactoryBean sqlSessionFactoryBean(DataSource dataSource) throws Exception
//    {
//        ResourcePatternResolver patternResolver = new PathMatchingResourcePatternResolver();
//        SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
//        sqlSessionFactoryBean.setDataSource(dataSource);
//        sqlSessionFactoryBean.setTypeAliasesPackage("com.hu.entity");
//        sqlSessionFactoryBean.setMapperLocations(patternResolver.getResources("classpath:mapping/*Mapper.xml"));
//        return sqlSessionFactoryBean;
//    }
//}
