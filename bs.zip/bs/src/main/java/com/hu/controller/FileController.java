package com.hu.controller;

import java.io.File;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

@Controller
@RequestMapping(value = "/file")
public class FileController {
    	
    @RequestMapping(value = "/commUploadA")
	@ResponseBody
	public String commUploadA(HttpServletRequest request) {
		try {
		    //直接new一个CommonsMultipartResolver
			CommonsMultipartResolver cmr = new CommonsMultipartResolver(request.getServletContext());
			cmr.setDefaultEncoding("utf-8");
			cmr.setMaxInMemorySize(40960);
			cmr.setMaxUploadSize(10485760000L);
			if (cmr.isMultipart(request)) {
				MultipartHttpServletRequest multipartRequest = cmr.resolveMultipart(request);
				MultipartFile file = multipartRequest.getFile("uploadFile");// 与页面input的name相同
				File imageFile = new File("d:/upload1.jpg");// 上传后的文件保存目录及名字
				file.transferTo(imageFile);// 将上传文件保存到相应位置
				return "";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}

}
