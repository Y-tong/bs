package com.hu.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hu.dao.AudioDao;
import com.hu.entity.Audio;
/**
 * 音频的Service
 * @author 10851
 *
 */
@Service
public class AudioService {

	@Resource
	private AudioDao audioDao;

	// 查询所有音频
	public List<Audio> list(Integer csid) {
		return audioDao.list(csid);
	}

	// 删除音频
	public void delete(Integer auid) {
		audioDao.delete(auid);
	}

	// 根据id查询音频
	public Audio findByAuid(Integer auid) {
		return audioDao.findByAuid(auid);
	}

	// 更改数据库中音频路径
	public void updateLocal(Audio local) {
		audioDao.updateLocal(local);	
	}

	// 更改音频其他信息
	public void update(Audio audio) {
		audioDao.update(audio);
	}

	// 根据id查询数据库中音频路径
	public String findLocalByAuid(Integer auid) {
		return audioDao.findLocalByAuid(auid);
	}

	// 添加音频信息
	public void add(Audio audio) {
		audioDao.add(audio);
	}
	
}
