package com.hu.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.hu.entity.Category;

@Repository
public interface CategoryDao {

	public List<Category> getCategorys();

}
