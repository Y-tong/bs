package com.hu.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.hu.entity.Discuss;

/**
 * 讨论区的Dao
 * @author 10851
 *
 */
@Repository
public interface DiscussDao {

	List<Discuss> list();

	void release(@Param("title") String title, @Param("content") String content, @Param("author") String author,@Param("date") String date);

	Discuss findDiscussById(@Param("disid") Integer disid);

	void delete(@Param("disid") Integer disid);
	
}
