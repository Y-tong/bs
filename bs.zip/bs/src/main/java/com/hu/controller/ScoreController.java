package com.hu.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hu.entity.Score;
import com.hu.entity.Video;
import com.hu.service.ScoreService;
/**
 * 曲谱的Controller
 * @author 10851
 *
 */
@Controller
public class ScoreController {

	@Resource
	private ScoreService scoreService;
	
	// 搜索查看具体曲谱内容
	@RequestMapping("/search/score")
	public String SearchScoreContent(Model model, @RequestParam(value="sid",required=true)Integer sid) {
		Score score = scoreService.findBySid(sid);
		model.addAttribute("score", score);
		return "views/content/scorecontent";
	}
	
	// 查看具体曲谱内容
	@RequestMapping("/content/score")
	public String ScoreContent(Model model, @RequestParam(value="sid",required=true)Integer sid, @RequestParam(value="csid",required=true)Integer csid) {
		Score score = scoreService.findBySid(sid);
		int isFirst = scoreService.findFirstSid(csid);
		
		if(score.getSid() == isFirst) {
			model.addAttribute("isfirst", 1);
		}
		int isLast = scoreService.findLastSid(csid);
		if(score.getSid() == isLast) {
			model.addAttribute("islast", 1);
		}
//			System.out.println("-----------"+article.getAid()+"--"+isFirst+isLast);
		model.addAttribute("score", score);
		model.addAttribute("csid", csid);
		return "views/content/scorecontent";
	}
	
	// 查看上一个
	@RequestMapping("/content/score/previous")
	public String PreviousContent(Model model, @RequestParam(value="sid",required=true)Integer sid, @RequestParam(value="csid",required=true)Integer csid) {
		Score score = scoreService.findPrevious(sid,csid);
//				System.out.println("--------"+article.getAid());
		model.addAttribute("score", score);
		int isFirst = scoreService.findFirstSid(csid);
		if(score.getSid() == isFirst) {
			model.addAttribute("isfirst", 1);
		}
		int isLast = scoreService.findLastSid(csid);
		if(score.getSid() == isLast) {
			model.addAttribute("islast", 1);
		}
		model.addAttribute("csid", csid);
		return "views/content/scorecontent";
	}
	
	// 查看下一个
	@RequestMapping("/content/score/next")
	public String NextContent(Model model, @RequestParam(value="sid",required=true)Integer sid, @RequestParam(value="csid",required=true)Integer csid) {
		Score score = scoreService.findNext(sid,csid);
//		System.out.println("--------"+article.getContent());
		model.addAttribute("score", score);
		int isFirst = scoreService.findFirstSid(csid);
		if(score.getSid() == isFirst) {
			model.addAttribute("isfirst", 1);
		}
		int isLast = scoreService.findLastSid(csid);
		if(score.getSid() == isLast) {
			model.addAttribute("islast", 1);
		}
		model.addAttribute("csid", csid);
		return "views/content/scorecontent";
	}
}
