package com.hu.entity;

import java.util.List;

/**
 * 一级分类实体类
 * @author 10851
 *
 */
public class Category {

	private String cname;
	private int cid;
	private List<CategorySecond> categoryseconds;
	
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public List<CategorySecond> getCategoryseconds() {
		return categoryseconds;
	}
	public void setCategoryseconds(List<CategorySecond> categoryseconds) {
		this.categoryseconds = categoryseconds;
	}
	
}
