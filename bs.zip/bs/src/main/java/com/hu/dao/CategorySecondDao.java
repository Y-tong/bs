package com.hu.dao;

import org.springframework.stereotype.Repository;

@Repository
public interface CategorySecondDao {

}