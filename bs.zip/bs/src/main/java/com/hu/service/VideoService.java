package com.hu.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hu.dao.VideoDao;
import com.hu.entity.Article;
import com.hu.entity.Video;
/**
 * video的Service
 * @author 10851
 *
 */
@Service
public class VideoService {

	@Resource
	private VideoDao videoDao;
	
	// 查找全部视频
	public List<Video> list(Integer csid) {
		return videoDao.list(csid);
	}

	// 根据vid查找视频
	public Video findByVid(Integer vid) {
		return videoDao.findByVid(vid);
	}

	// 查找第一个vid
	public int findFirstVid(Integer csid) {
		return videoDao.findFirstVid(csid);
	}

	// 查找最后一个vid
	public int findLastVid(Integer csid) {
		return videoDao.findLastVid(csid);
	}

	// 查看上一个视频
	public Video findPrevious(Integer vid, Integer csid) {
		return videoDao.findPrevious(vid, csid);
	}

	// 查看下一个视频
	public Video findNext(Integer vid, Integer csid) {
		return videoDao.findNext(vid, csid);
	}

	// 删除数据库记录
	public void delete(Integer vid) {
		videoDao.delete(vid);
	}

	// 根据id查找视频
	public Video findLocalByVid(Integer vid) {
		return videoDao.findLocalByVid(vid);
	}

	// 更新视频信息
	public void update(Video video) {
		videoDao.update(video);
	}

	// 更改图片路径
	public void updateImage(Video video) {
		videoDao.updateImage(video);
	}

	// 更新视频路径
	public void updateLocal(Video videotwo) {
		videoDao.updateLocal(videotwo);
	}

	// 添加视频信息
	public void add(Video video) {
		videoDao.add(video);
	}

}
