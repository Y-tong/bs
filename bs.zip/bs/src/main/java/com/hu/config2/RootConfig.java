package com.hu.config2;
//package com.hu.config;
//
//import org.springframework.context.annotation.*;
//import org.springframework.web.servlet.config.annotation.EnableWebMvc;
//
//@Configuration
//@Import(DataConfig.class)
///**
// * 设置扫描机制的时候，将之前WebConfig设置过的那个包排除了；
// */
//@ComponentScan(basePackages = {"com.hu"},
//    excludeFilters = {@ComponentScan.Filter(type = FilterType.ANNOTATION,
//            value = EnableWebMvc.class)})
//public class RootConfig {
//
//}
