package com.hu.config2;
//package com.hu.config;
//
//import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;
//
///**
// * 扩展AbstractAnnotationConfigDispatcherServletInitializer的任意类都会自动地配置
// * DispatcherServlet和Spring应用上下文，Spring的应用上下文会位于应用程序的Servlet上下文之中
// */
//public class MpdidbWebAppInitializer extends AbstractAnnotationConfigDispatcherServletInitializer
//{
//    /**
//     *返回带有@Configuration注解的类将会用来配置ContextLoaderListener创建应用的应用上下文中的bean。
//     * ContextLoaderListener要加载应用中的其他bean，这些bean通常是驱动应用后端的中间层和数据层的组件。
//     */
//    @Override
//    protected Class<?>[] getRootConfigClasses()
//    {
//        return new Class<?>[] {RootConfig.class};
//    }
//
//    /**
//     *返回带有@Configuration注解的类将会用来定义DispatcherServlet应用上下文中的bean。
//     * DispatcherServlet加载包含Web组件的bean，如控制器、视图解析器以及处理器映射器。
//     */
//    @Override
//    protected Class<?>[] getServletConfigClasses()
//    {
//        return new Class<?>[] {WebConfig.class};
//    }
//
//    /**
//     * 将一个或多个路径映射到DispatcherServlet上，
//     * 此处它的映射是“/”，即默认的Servlet,会处理进入应用的所有请求
//     */
//    @Override
//    protected String[] getServletMappings()
//    {
//        return new String[] { "/" };
//    }
//}
