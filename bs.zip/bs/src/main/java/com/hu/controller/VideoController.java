package com.hu.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hu.entity.Article;
import com.hu.entity.Video;
import com.hu.service.VideoService;
/**
 * video的Controller
 * @author 10851
 *
 */
@Controller
public class VideoController {

	@Resource
	private VideoService videoService;
	
	// 查看具体视频内容
	@RequestMapping("/content/video")
	public String ArtcileContent(Model model, @RequestParam(value="vid",required=true)Integer vid, @RequestParam(value="csid",required=true)Integer csid) {
		Video video = videoService.findByVid(vid);
		int isFirst = videoService.findFirstVid(csid);
		
		if(video.getVid() == isFirst) {
			model.addAttribute("isfirst", 1);
		}
		int isLast = videoService.findLastVid(csid);
		if(video.getVid() == isLast) {
			model.addAttribute("islast", 1);
		}
////		System.out.println("-----------"+article.getAid()+"--"+isFirst+isLast);
		model.addAttribute("video", video);
		model.addAttribute("csid", csid);
		return "views/content/coursecontent";
	}
	
	// 查看上一个
		@RequestMapping("/content/video/previous")
		public String PreviousArtcileContent(Model model, @RequestParam(value="vid",required=true)Integer vid, @RequestParam(value="csid",required=true)Integer csid) {
			Video video = videoService.findPrevious(vid, csid);
//			System.out.println("--------"+article.getAid());
			model.addAttribute("video", video);
			int isFirst = videoService.findFirstVid(csid);
			if(video.getVid() == isFirst) {
				model.addAttribute("isfirst", 1);
			}
			int isLast = videoService.findLastVid(csid);
			if(video.getVid() == isLast) {
				model.addAttribute("islast", 1);
			}
			model.addAttribute("csid", csid);
			return "views/content/coursecontent";
		}
		
		// 查看下一个
		@RequestMapping("/content/video/next")
		public String NextArtcileContent(Model model, @RequestParam(value="vid",required=true)Integer vid, @RequestParam(value="csid",required=true)Integer csid) {
			Video video = videoService.findNext(vid, csid);
//			System.out.println("--------"+article.getContent());
			model.addAttribute("video", video);
			int isFirst = videoService.findFirstVid(csid);
			if(video.getVid() == isFirst) {
				model.addAttribute("isfirst", 1);
			}
			int isLast = videoService.findLastVid(csid);
			if(video.getVid() == isLast) {
				model.addAttribute("islast", 1);
			}
			model.addAttribute("csid", csid);
			return "views/content/coursecontent";
		}
}
