package com.hu.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hu.dao.ScoreDao;
import com.hu.entity.Score;
/**
 * 曲谱的Service
 * @author 10851
 *
 */
@Service
public class ScoreService {

	@Resource
	private ScoreDao scoreDao;

	// 根据csid查找所有曲谱
	public List<Score> list(Integer csid) {
		return scoreDao.list(csid);
	}

	// 根据sid查找曲谱
	public Score findBySid(Integer sid) {
		return scoreDao.findBySid(sid);
	}

	// 查找第一个曲谱的sid
	public int findFirstSid(Integer csid) {
		return scoreDao.findFirstSid(csid);
	}

	// 查找最后一个曲谱的sid
	public int findLastSid(Integer csid) {
		return scoreDao.findLastSid(csid);
	}

	// 上一个
	public Score findPrevious(Integer sid, Integer csid) {
		return scoreDao.findPrevious(sid, csid);
	}

	// 下一个
	public Score findNext(Integer sid, Integer csid) {
		return scoreDao.findNext(sid, csid);
	}

	// 根据id查找储存的图片地址
	public String findLocalBySid(Integer sid) {
		return scoreDao.findLocalBySid(sid);
	}

	// 删除数据库中内容
	public void delete(Integer sid) {
		scoreDao.delete(sid);
	}

	// 更改图片信息
	public void update(Score score) {
		scoreDao.update(score);
	}

	// 更改图片路径
	public void updateLocal(Score score) {
		scoreDao.updateLocal(score);
	}

	// 添加乐谱信息
	public void add(Score score) {
		scoreDao.add(score);
	}

	// 曲谱查询
	public List<Score> search(String searchtext) {
		return scoreDao.search(searchtext);
	}
}
