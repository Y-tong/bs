package com.hu.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;

import com.hu.service.AudioService;
/**
 * audio的controller
 * @author 10851
 *
 */
@Controller
public class AudioController {

	@Resource
	private AudioService audioService;
}
