package com.hu.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hu.entity.Admin;
import com.hu.entity.Article;
import com.hu.entity.Audio;
import com.hu.entity.Discuss;
import com.hu.entity.Reply;
import com.hu.entity.Score;
import com.hu.entity.User;
import com.hu.entity.Video;
import com.hu.service.AdminService;
import com.hu.service.ArticleService;
import com.hu.service.AudioService;
import com.hu.service.DiscussService;
import com.hu.service.ReplyService;
import com.hu.service.ScoreService;
import com.hu.service.UserService;
import com.hu.service.VideoService;

/**
 * 管理界面的controller
 * @author 10851
 *
 */
@Controller
public class AdminController {

	@Resource
	private AdminService adminService;
	
	@Resource
	private UserService userService;
	
	@Resource
	private ArticleService articleService;
	
	@Resource
	private DiscussService discussService;
	
	@Resource
	private ReplyService replyService;
	
	@Resource
	private AudioService audioService;
	
	@Resource
	private ScoreService scoreService;

	@Resource
	private VideoService videoService;
	
	// 进入管理员登录界面
	@RequestMapping("/admin")
    public String index() {
		return "views/admin/index";
	}
	
	// 管理员登录操作
	@RequestMapping(value="/admin/login", method = RequestMethod.POST)
    public String adminlogin(HttpServletRequest request, Model model,@ModelAttribute Admin admin) {
//		System.out.println("----"+admin.getPassword()+admin.getUsername());
		if (adminService.signin(admin.getUsername(), admin.getPassword())) {
            request.getSession().setAttribute("admin", admin);
            model.addAttribute("admin", admin);
            return "views/admin/home";
        } else {
            model.addAttribute("error", "用户名或密码错误");
            return "redirect:/admin";
        }
		
	}
	
	// 进入用户管理界面
	@RequestMapping("/admin/user")
	public String adminuser(ModelMap map, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		Integer pageSize = 2;
		PageHelper.startPage(pageNo, pageSize);
		List<User> userList = userService.list();
		PageInfo<User> pageInfo = new PageInfo<User>(userList);
		map.addAttribute("pageInfo", pageInfo);
//		System.out.println(pageInfo);
		return "views/admin/user/list";
	}
	
	// 管理员删除用户
	@RequestMapping("/admin/user/delete/{userId}")
	public String admindeleteuser(@PathVariable("userId") Integer userId, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		userService.delete(userId);
		return "redirect:/admin/user?pageNo="+pageNo;
	}
	
	// 管理员进入修改用户界面
	@RequestMapping("/admin/user/edit/{userId}")
	public String adminedituser(Model model, @PathVariable("userId") Integer userId, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		User user = userService.getById(userId);
		model.addAttribute("user", user);
		model.addAttribute("pageNo", pageNo);
		return "views/admin/user/edit";
	}
	
	// 管理员进行用户信息修改
	@RequestMapping(value="/admin/user/update", method = RequestMethod.POST)
	public String adminupdateuser(Model model, @ModelAttribute User user, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		userService.update(user);
		return "redirect:/admin/user?pageNo="+pageNo;
	}
	
	// 进入文章管理界面
	@RequestMapping("/admin/article")
	public String adminarticle(ModelMap map, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		Integer pageSize = 2;
		PageHelper.startPage(pageNo, pageSize);
		List<Article> articleList = articleService.list(1);
		PageInfo<Article> pageInfo = new PageInfo<Article>(articleList);
		map.addAttribute("pageInfo", pageInfo);
		return "views/admin/categorysecond/list";
	}
		
	// 管理员删除文章
	@RequestMapping("/admin/article/delete/{aid}")
	public String admindeletearticle(@PathVariable("aid") Integer aid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		articleService.delete(aid);
		return "redirect:/admin/article?pageNo="+pageNo;
	}	
	
	// 管理员进入编辑文章界面
	@RequestMapping("/admin/article/update/{aid}")
	public String adminarticleupdate(ModelMap map, @PathVariable("aid") Integer aid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		Article article = articleService.findByAid(aid);
		map.addAttribute("article", article);
		map.addAttribute("pageNo", pageNo);
		return "views/admin/categorysecond/edit";
	}	
	
	// 管理员更改文章
	@RequestMapping(value="/admin/article/doupdate", method = RequestMethod.POST)
	public String adminarticledoupdate(@ModelAttribute Article article, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		articleService.update(article);
//		System.out.println("更新完毕");
		return "redirect:/admin/article?pageNo="+pageNo;
	}
	
	// 管理员进入添加文章页面
	@RequestMapping("/admin/article/add")
	public String adminarticleadd() {
		return "views/admin/categorysecond/add";
	}
	
	// 管理员进入添加文章页面
	@RequestMapping(value="/admin/article/doadd", method = RequestMethod.POST)
	public String adminarticledoadd(@ModelAttribute Article article) {
		article.setCsid(1);
		articleService.add(article);
		return "redirect:/admin/article";
	}
	
	// 进入讨论区帖子管理界面
	@RequestMapping("/admin/discuss")
	public String admindiscuss(ModelMap map, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		Integer pageSize = 2;
		PageHelper.startPage(pageNo, pageSize);
		List<Discuss> discussList = discussService.list();
		PageInfo<Discuss> pageInfo = new PageInfo<Discuss>(discussList);
		map.addAttribute("pageInfo", pageInfo);
		return "views/admin/discuss/discusslist";
	}
		
	// 进入讨论区帖子回复管理界面
	@RequestMapping("/admin/discuss/reply/{disid}/{pageNum}")
	public String adminreply(@PathVariable("pageNum") Integer pageNum,@PathVariable("disid") Integer disid,ModelMap map, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		Integer pageSize = 2;
		PageHelper.startPage(pageNo, pageSize);
		List<Reply> replyList = replyService.list(disid);
		PageInfo<Reply> pageInfo = new PageInfo<Reply>(replyList);
		map.addAttribute("pageInfo", pageInfo);
		map.addAttribute("disid", disid);
		map.addAttribute("pageNum", pageNum);
		return "views/admin/discuss/replylist";
	}	
		
	// 管理员删除回复
	@RequestMapping("/admin/discuss/reply/delete/{rid}/{disid}/{pageNum}")
	public String admindeletereply(Model model, @PathVariable("pageNum") Integer pageNum, @PathVariable("rid") Integer rid, @PathVariable("disid") Integer disid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		replyService.delete(rid);
		model.addAttribute("pageNum", pageNum);
		return "redirect:/admin/discuss/reply/"+disid+"/"+pageNum+"?pageNo="+pageNo;
	}
	
	// 管理员删除帖子
	@RequestMapping("/admin/discuss/delete/{disid}")
	public String admindeleterdiscuss(@PathVariable("disid") Integer disid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		replyService.deleteByDisid(disid);
		discussService.delete(disid);
		return "redirect:/admin/discuss?pageNo="+pageNo;
	}
	
	// 回归帖子管理界面
	@RequestMapping("/admin/discuss/reply/goback")
	public String admindiscussgoback(@RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		return "redirect:/admin/discuss?pageNo="+pageNo;
	}
	
	// 进入音频欣赏管理界面
	@RequestMapping("/admin/audio")
	public String adminaudio(ModelMap map, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		Integer pageSize = 2;
		PageHelper.startPage(pageNo, pageSize);
		List<Audio> audioList = audioService.list(3);
		PageInfo<Audio> pageInfo = new PageInfo<Audio>(audioList);
		map.addAttribute("pageInfo", pageInfo);
		return "views/admin/audio/audiolist";
	}

	// 管理员删除音频
	@RequestMapping("/admin/audio/delete/{auid}")
	public String admindeleteraudio(@PathVariable("auid") Integer auid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		// 将音频也删了
		String oldName = audioService.findLocalByAuid(auid);
		if(oldName != null) {
			File fileold = new File("D:\\youku\\Youku Files\\transcode\\mp3\\"+oldName.substring(3, oldName.length()));
			fileold.delete();
		}
		// 后删数据库记录
		audioService.delete(auid);
		return "redirect:/admin/audio?pageNo="+pageNo;
	}
	
	// 管理员进入编辑音频界面
	@RequestMapping("/admin/audio/update/{auid}")
	public String adminaudioupdate(ModelMap map, @PathVariable("auid") Integer auid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		Audio audio = audioService.findByAuid(auid);
		map.addAttribute("audio", audio);
		map.addAttribute("pageNo", pageNo);
		return "views/admin/audio/edit";
	}	
	
	// 管理员更改音频
	@RequestMapping(value="/admin/audio/doupdate/{auid}", method = RequestMethod.POST)
	public String adminaudiooupdatemp3(HttpServletRequest request,@PathVariable("auid") Integer auid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		// 上传:
		//直接new一个CommonsMultipartResolver
		try {
			CommonsMultipartResolver cmr = new CommonsMultipartResolver(request.getServletContext());
			cmr.setDefaultEncoding("utf-8");
			cmr.setMaxInMemorySize(40960);
			cmr.setMaxUploadSize(10485760000L);
			if (cmr.isMultipart(request)) {
				MultipartHttpServletRequest multipartRequest = cmr.resolveMultipart(request);
				MultipartFile file = multipartRequest.getFile("mp3");// 与页面input的name相同
				System.out.println("-----"+file.getOriginalFilename());
				String local = "mp3/"+file.getOriginalFilename();
				File imageFile = new File("d:/youku/Youku Files/transcode/mp3/"+file.getOriginalFilename());// 上传后的文件保存目录及名字
				
				// 将上传文件保存到相应位置
				file.transferTo(imageFile);
				// 删除原文件
				String oldName = audioService.findLocalByAuid(auid);
				if(oldName != null) {
					File fileold = new File("D:\\youku\\Youku Files\\transcode\\mp3\\"+oldName.substring(3, oldName.length()));
					fileold.delete();
				}
//				System.out.println(audioService.findLocalByAuid(auid));
//				System.out.println(fileold.getName()+"---"+fileold.getPath());
				// 更新音频路径
				Audio audio = new Audio();
				audio.setLocal(local);
				audio.setAuid(auid);
				audioService.updateLocal(audio);
				return "redirect:/admin/audio?pageNo="+pageNo;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
//		audioService.update(audio);
//			System.out.println("更新完毕");
		return "redirect:/admin/audio?pageNo="+pageNo;
	}
		
	// 管理员更改音频
	@RequestMapping(value="/admin/audio/doupdate", method = RequestMethod.POST)
	public String adminaudiooupdate(@ModelAttribute Audio audio, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		audioService.update(audio);
		return "redirect:/admin/audio?pageNo="+pageNo;
	}
	
	// 进去音频添加页面
	@RequestMapping(value="/admin/audio/goadd")
	public String goadd() {
		return "views/admin/audio/add";
	}
	
	// 添加音频相关信息，然后进入添加音频界面
	@RequestMapping(value="/admin/audio/add", method = RequestMethod.POST)
	public String adminaudioadd(Model model,@ModelAttribute Audio audio) {
		audio.setCsid(3);
		audioService.add(audio);
		model.addAttribute("auid", audio.getAuid());
		return "views/admin/audio/addtwo";
	}
	
	// 管理员添加信息后添加音频
		@RequestMapping(value="/admin/audio/addtwo/{auid}", method = RequestMethod.POST)
		public String adminaudioaddtwo(HttpServletRequest request,@PathVariable("auid") Integer auid) {
			// 上传:
			//直接new一个CommonsMultipartResolver
			try {
				CommonsMultipartResolver cmr = new CommonsMultipartResolver(request.getServletContext());
				cmr.setDefaultEncoding("utf-8");
				cmr.setMaxInMemorySize(40960);
				cmr.setMaxUploadSize(10485760000L);
				if (cmr.isMultipart(request)) {
					MultipartHttpServletRequest multipartRequest = cmr.resolveMultipart(request);
					MultipartFile file = multipartRequest.getFile("mp3");// 与页面input的name相同
					System.out.println("-----"+file.getOriginalFilename());
					String local = "mp3/"+file.getOriginalFilename();
					File imageFile = new File("d:/youku/Youku Files/transcode/mp3/"+file.getOriginalFilename());// 上传后的文件保存目录及名字
					
					// 将上传文件保存到相应位置
					file.transferTo(imageFile);
					
//					System.out.println(audioService.findLocalByAuid(auid));
//					System.out.println(fileold.getName()+"---"+fileold.getPath());
					// 更新音频路径
					Audio audio = new Audio();
					audio.setLocal(local);
					audio.setAuid(auid);
					audioService.updateLocal(audio);
					return "redirect:/admin/audio";
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
//			audioService.update(audio);
//				System.out.println("更新完毕");
			return "redirect:/admin/audio";
		}
	
	// 进入流行乐曲管理界面
	@RequestMapping("/admin/image")
	public String adminimage(ModelMap map, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		Integer pageSize = 2;
		PageHelper.startPage(pageNo, pageSize);
		List<Score> scoreList = scoreService.list(5);
		PageInfo<Score> pageInfo = new PageInfo<Score>(scoreList);
		map.addAttribute("pageInfo", pageInfo);
		return "views/admin/image/imagelist";
	}	
	
	// 进入流行乐曲管理界面
	@RequestMapping("/admin/imagetwo")
	public String adminimagetwo(ModelMap map, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		Integer pageSize = 2;
		PageHelper.startPage(pageNo, pageSize);
		List<Score> scoreList = scoreService.list(6);
		PageInfo<Score> pageInfo = new PageInfo<Score>(scoreList);
		map.addAttribute("pageInfo", pageInfo);
		return "views/admin/image/imagelisttwo";
	}	
	
	// 管理员删除图片
	@RequestMapping("/admin/image/delete/{sid}")
	public String admindeleteimage(@PathVariable("sid") Integer sid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		// 将图片也删了
		String oldName = scoreService.findLocalBySid(sid);
		if(oldName != null) {
			File fileold = new File("D:\\youku\\Youku Files\\transcode\\qupu\\"+oldName.substring(4, oldName.length()));
			fileold.delete();
		}
		// 后删数据库记录
		scoreService.delete(sid);
		return "redirect:/admin/image?pageNo="+pageNo;
	}
	
	// 管理员删除图片
	@RequestMapping("/admin/imagetwo/delete/{sid}")
	public String admindeleteimagetwo(@PathVariable("sid") Integer sid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		// 将图片也删了
		String oldName = scoreService.findLocalBySid(sid);
		if(oldName != null) {
			File fileold = new File("D:\\youku\\Youku Files\\transcode\\qupu\\"+oldName.substring(4, oldName.length()));
			fileold.delete();
		}
		// 后删数据库记录
		scoreService.delete(sid);
		return "redirect:/admin/imagetwo?pageNo="+pageNo;
	}
	
	// 管理员进入编辑图片界面
	@RequestMapping("/admin/image/update/{sid}")
	public String adminimageupdate(ModelMap map, @PathVariable("sid") Integer sid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		Score score = scoreService.findBySid(sid);
		map.addAttribute("score", score);
		map.addAttribute("pageNo", pageNo);
		return "views/admin/image/edit";
	}	
	
	// 管理员进入编辑图片界面
	@RequestMapping("/admin/imagetwo/update/{sid}")
	public String adminimagetwoupdate(ModelMap map, @PathVariable("sid") Integer sid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		Score score = scoreService.findBySid(sid);
		map.addAttribute("score", score);
		map.addAttribute("pageNo", pageNo);
		return "views/admin/image/edittwo";
	}
	
	// 管理员更改图片信息
	@RequestMapping(value="/admin/image/doupdate", method = RequestMethod.POST)
	public String adminimageoupdate(@ModelAttribute Score score, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		scoreService.update(score);
		return "redirect:/admin/image?pageNo="+pageNo;
	}
	
	// 管理员更改图片信息
	@RequestMapping(value="/admin/imagetwo/doupdate", method = RequestMethod.POST)
	public String adminimagetwooupdate(@ModelAttribute Score score, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		scoreService.update(score);
		return "redirect:/admin/imagetwo?pageNo="+pageNo;
	}
	
	// 管理员更改图片
		@RequestMapping(value="/admin/image/doupdate/{sid}", method = RequestMethod.POST)
		public String adminscoreupdateimage(HttpServletRequest request,@PathVariable("sid") Integer sid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
			// 上传:
			//直接new一个CommonsMultipartResolver
			try {
				CommonsMultipartResolver cmr = new CommonsMultipartResolver(request.getServletContext());
				cmr.setDefaultEncoding("utf-8");
				cmr.setMaxInMemorySize(40960);
				cmr.setMaxUploadSize(10485760000L);
				if (cmr.isMultipart(request)) {
					MultipartHttpServletRequest multipartRequest = cmr.resolveMultipart(request);
					MultipartFile file = multipartRequest.getFile("image");// 与页面input的name相同
					System.out.println("-----"+file.getOriginalFilename());
					String local = "qupu/"+file.getOriginalFilename();
					File imageFile = new File("d:/youku/Youku Files/transcode/qupu/"+file.getOriginalFilename());// 上传后的文件保存目录及名字
					
					// 将上传文件保存到相应位置
					file.transferTo(imageFile);
					// 删除原文件
					String oldName = scoreService.findLocalBySid(sid);
					if(oldName != null) {
						File fileold = new File("D:\\youku\\Youku Files\\transcode\\qupu\\"+oldName.substring(4, oldName.length()));
						fileold.delete();
					}
					Score score = new Score();
					score.setImage(local);
					score.setSid(sid);
					scoreService.updateLocal(score);
					return "redirect:/admin/image?pageNo="+pageNo;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return "redirect:/admin/image?pageNo="+pageNo;
		}
	
	// 管理员更改图片
	@RequestMapping(value="/admin/imagetwo/doupdate/{sid}", method = RequestMethod.POST)
	public String adminscoreupdateimagetwo(HttpServletRequest request,@PathVariable("sid") Integer sid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		// 上传:
		//直接new一个CommonsMultipartResolver
		try {
			CommonsMultipartResolver cmr = new CommonsMultipartResolver(request.getServletContext());
			cmr.setDefaultEncoding("utf-8");
			cmr.setMaxInMemorySize(40960);
			cmr.setMaxUploadSize(10485760000L);
			if (cmr.isMultipart(request)) {
				MultipartHttpServletRequest multipartRequest = cmr.resolveMultipart(request);
				MultipartFile file = multipartRequest.getFile("image");// 与页面input的name相同
				System.out.println("-----"+file.getOriginalFilename());
				String local = "qupu/"+file.getOriginalFilename();
				File imageFile = new File("d:/youku/Youku Files/transcode/qupu/"+file.getOriginalFilename());// 上传后的文件保存目录及名字
				
				// 将上传文件保存到相应位置
				file.transferTo(imageFile);
				// 删除原文件
				String oldName = scoreService.findLocalBySid(sid);
				if(oldName != null) {
					File fileold = new File("D:\\youku\\Youku Files\\transcode\\qupu\\"+oldName.substring(4, oldName.length()));
					fileold.delete();
				}
				Score score = new Score();
				score.setImage(local);
				score.setSid(sid);
				scoreService.updateLocal(score);
				return "redirect:/admin/imagetwo?pageNo="+pageNo;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/admin/imagetwo?pageNo="+pageNo;
	}	
		
	// 进去图片添加页面
	@RequestMapping(value="/admin/image/goadd")
	public String goaddimage() {
		return "views/admin/image/add";
	}
	
	// 进去图片添加页面
	@RequestMapping(value="/admin/imagetwo/goadd")
	public String goaddimagetwo() {
		return "views/admin/image/addnation";
	}
	
	// 添加乐谱相关信息，然后进入添加图片界面
	@RequestMapping(value="/admin/image/add", method = RequestMethod.POST)
	public String adminimageadd(Model model,@ModelAttribute Score score) {
		scoreService.add(score);
		model.addAttribute("sid", score.getSid());
		return "views/admin/image/addtwo";
	}
	
	// 添加乐谱相关信息，然后进入添加图片界面
	@RequestMapping(value="/admin/imagetwo/add", method = RequestMethod.POST)
	public String adminimagetwoadd(Model model,@ModelAttribute Score score) {
		scoreService.add(score);
		model.addAttribute("sid", score.getSid());
		return "views/admin/image/addnationtwo";
	}
	
	// 管理员添加音频
	@RequestMapping(value="/admin/image/addtwo/{sid}", method = RequestMethod.POST)
	public String adminimageaddtwo(HttpServletRequest request,@PathVariable("sid") Integer sid) {
		// 上传:
		//直接new一个CommonsMultipartResolver
		try {
			CommonsMultipartResolver cmr = new CommonsMultipartResolver(request.getServletContext());
			cmr.setDefaultEncoding("utf-8");
			cmr.setMaxInMemorySize(40960);
			cmr.setMaxUploadSize(10485760000L);
			if (cmr.isMultipart(request)) {
				MultipartHttpServletRequest multipartRequest = cmr.resolveMultipart(request);
				MultipartFile file = multipartRequest.getFile("image");// 与页面input的name相同
				System.out.println("-----"+file.getOriginalFilename());
				String local = "qupu/"+file.getOriginalFilename();
				File imageFile = new File("d:/youku/Youku Files/transcode/qupu/"+file.getOriginalFilename());// 上传后的文件保存目录及名字
				
				// 将上传文件保存到相应位置
				file.transferTo(imageFile);
				Score score = new Score();
				score.setImage(local);
				score.setSid(sid);
			
				scoreService.updateLocal(score);
				return "redirect:/admin/image";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/admin/image";
	}
	
	// 管理员添加音频
	@RequestMapping(value="/admin/imagetwo/addtwo/{sid}", method = RequestMethod.POST)
	public String adminimagetwoaddtwo(HttpServletRequest request,@PathVariable("sid") Integer sid) {
		// 上传:
		//直接new一个CommonsMultipartResolver
		try {
			CommonsMultipartResolver cmr = new CommonsMultipartResolver(request.getServletContext());
			cmr.setDefaultEncoding("utf-8");
			cmr.setMaxInMemorySize(40960);
			cmr.setMaxUploadSize(10485760000L);
			if (cmr.isMultipart(request)) {
				MultipartHttpServletRequest multipartRequest = cmr.resolveMultipart(request);
				MultipartFile file = multipartRequest.getFile("image");// 与页面input的name相同
				System.out.println("-----"+file.getOriginalFilename());
				String local = "qupu/"+file.getOriginalFilename();
				File imageFile = new File("d:/youku/Youku Files/transcode/qupu/"+file.getOriginalFilename());// 上传后的文件保存目录及名字
				
				// 将上传文件保存到相应位置
				file.transferTo(imageFile);
				Score score = new Score();
				score.setImage(local);
				score.setSid(sid);
			
				scoreService.updateLocal(score);
				return "redirect:/admin/imagetwo";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/admin/imagetwo";
	}
	
	// 进入教程视频管理界面
	@RequestMapping("/admin/video")
	public String adminvideo(ModelMap map, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		Integer pageSize = 2;
		PageHelper.startPage(pageNo, pageSize);
		List<Video> videoList = videoService.list(2);
		PageInfo<Video> pageInfo = new PageInfo<Video>(videoList);
		map.addAttribute("pageInfo", pageInfo);
		return "views/admin/video/videolist";
	}
	
	// 进入欣赏视频管理界面
	@RequestMapping("/admin/videotwo")
	public String adminvideotwo(ModelMap map, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		Integer pageSize = 2;
		PageHelper.startPage(pageNo, pageSize);
		List<Video> videoList = videoService.list(4);
		PageInfo<Video> pageInfo = new PageInfo<Video>(videoList);
		map.addAttribute("pageInfo", pageInfo);
		return "views/admin/video/videolisttwo";
	}
	
	// 视频删除
	@RequestMapping("/admin/video/delete/{vid}")
	public String admindeletevideo(@PathVariable("vid") Integer vid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		// 将图片也删了
		Video video = videoService.findLocalByVid(vid);
		String oldName = video.getImage();
		if(oldName != null) {
			File fileold = new File("D:\\youku\\Youku Files\\transcode\\截图\\"+oldName.substring(3, oldName.length()));
			fileold.delete();
		}
		// 视频删掉
		String oldNametwo = video.getLocal();
		if(oldNametwo != null) {
			File fileoldtwo = new File("D:\\youku\\Youku Files\\transcode\\"+oldNametwo);
			fileoldtwo.delete();
		}
		// 后删数据库记录
		videoService.delete(vid);
		return "redirect:/admin/video?pageNo="+pageNo;
	}
	
	// 视频删除
	@RequestMapping("/admin/videotwo/delete/{vid}")
	public String admindeletevideotwo(@PathVariable("vid") Integer vid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		// 将图片也删了
		Video video = videoService.findLocalByVid(vid);
		String oldName = video.getImage();
		if(oldName != null) {
			File fileold = new File("D:\\youku\\Youku Files\\transcode\\截图\\"+oldName.substring(3, oldName.length()));
			fileold.delete();
		}
		// 视频删掉
		String oldNametwo = video.getLocal();
		if(oldNametwo != null) {
			File fileoldtwo = new File("D:\\youku\\Youku Files\\transcode\\"+oldNametwo);
			fileoldtwo.delete();
		}
		// 后删数据库记录
		videoService.delete(vid);
		return "redirect:/admin/videotwo?pageNo="+pageNo;
	}
	
	// 管理员进入编辑视频界面
	@RequestMapping("/admin/video/update/{vid}")
	public String adminvideoupdate(ModelMap map, @PathVariable("vid") Integer vid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		Video video = videoService.findLocalByVid(vid);
		map.addAttribute("video", video);
		map.addAttribute("pageNo", pageNo);
		return "views/admin/video/edit";
	}
	
	// 进入编辑视频界面
	@RequestMapping("/admin/videotwo/update/{vid}")
	public String adminvideotwoupdate(ModelMap map, @PathVariable("vid") Integer vid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		Video video = videoService.findLocalByVid(vid);
		map.addAttribute("video", video);
		map.addAttribute("pageNo", pageNo);
		return "views/admin/video/edittwo";
	}
	
	// 管理员更改视频信息
	@RequestMapping(value="/admin/video/doupdate", method = RequestMethod.POST)
	public String adminvideooupdate(@ModelAttribute Video video, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		videoService.update(video);
		return "redirect:/admin/video?pageNo="+pageNo;
	}
	
	// 管理员更改视频信息
	@RequestMapping(value="/admin/videotwo/doupdate", method = RequestMethod.POST)
	public String adminvideotwooupdate(@ModelAttribute Video video, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		videoService.update(video);
		return "redirect:/admin/videotwo?pageNo="+pageNo;
	}
	
	// 更改视频路径
	@RequestMapping(value="/admin/video/doupdate/{vid}", method = RequestMethod.POST)
	public String adminscoreupdatevideo(HttpServletRequest request,@PathVariable("vid") Integer vid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		// 上传:
		//直接new一个CommonsMultipartResolver
		try {
			CommonsMultipartResolver cmr = new CommonsMultipartResolver(request.getServletContext());
			cmr.setDefaultEncoding("utf-8");
			cmr.setMaxInMemorySize(40960);
			cmr.setMaxUploadSize(10485760000L);
			if (cmr.isMultipart(request)) {
				MultipartHttpServletRequest multipartRequest = cmr.resolveMultipart(request);
				// 获取图片，视频路径
				MultipartFile file = multipartRequest.getFile("image");// 与页面input的name相同
				String local = "截图/"+file.getOriginalFilename();
				System.out.println("-----"+local);
				File imageFile = new File("d:/youku/Youku Files/transcode/截图/"+file.getOriginalFilename());// 上传后的文件保存目录及名字
				
				MultipartFile filetwo = multipartRequest.getFile("video");// 与页面input的name相同
				String localtwo = filetwo.getOriginalFilename();
				File imageFiletwo = new File("d:/youku/Youku Files/transcode/"+filetwo.getOriginalFilename());// 上传后的文件保存目录及名字
				
				// 将上传文件保存到相应位置
				if(file.getSize() != 0) {
					file.transferTo(imageFile);
					// 删除原文件
					String oldName = videoService.findLocalByVid(vid).getImage();
					System.out.println(oldName);
					if(oldName != null && oldName.length() != 0) {
						File fileold = new File("D:\\youku\\Youku Files\\transcode\\截图\\"+oldName.substring(3, oldName.length()));
						fileold.delete();
					}
				}
				if(filetwo.getSize() != 0) {
					filetwo.transferTo(imageFiletwo);
					// 删除原文件
					String oldNametwo = videoService.findLocalByVid(vid).getLocal();
					System.out.println(oldNametwo);
					if(oldNametwo != null && oldNametwo.length() != 0) {
						File fileoldtwo = new File("D:\\youku\\Youku Files\\transcode\\"+oldNametwo);
						fileoldtwo.delete();
					}
				}
				
				// 更新图片，视频路径
				if(file.getSize() != 0) {
					Video video = new Video();
					video.setVid(vid);
					video.setImage(local);
					videoService.updateImage(video);
				}
				
				if(filetwo.getSize() != 0) {
					Video videotwo = new Video();
					videotwo.setVid(vid);
					videotwo.setLocal(localtwo);
					videoService.updateLocal(videotwo);
				}
				return "redirect:/admin/video?pageNo="+pageNo;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/admin/video?pageNo="+pageNo;
	}
	
	// 更改视频路径
	@RequestMapping(value="/admin/videotwo/doupdate/{vid}", method = RequestMethod.POST)
	public String adminscoreupdatevideotwo(HttpServletRequest request,@PathVariable("vid") Integer vid, @RequestParam(defaultValue="1",value="pageNo") Integer pageNo) {
		// 上传:
		//直接new一个CommonsMultipartResolver
		try {
			CommonsMultipartResolver cmr = new CommonsMultipartResolver(request.getServletContext());
			cmr.setDefaultEncoding("utf-8");
			cmr.setMaxInMemorySize(40960);
			cmr.setMaxUploadSize(10485760000L);
			if (cmr.isMultipart(request)) {
				MultipartHttpServletRequest multipartRequest = cmr.resolveMultipart(request);
				// 获取图片，视频路径
				MultipartFile file = multipartRequest.getFile("image");// 与页面input的name相同
				String local = "截图/"+file.getOriginalFilename();
				System.out.println("-----"+local);
				File imageFile = new File("d:/youku/Youku Files/transcode/截图/"+file.getOriginalFilename());// 上传后的文件保存目录及名字
				
				MultipartFile filetwo = multipartRequest.getFile("video");// 与页面input的name相同
				String localtwo = filetwo.getOriginalFilename();
				File imageFiletwo = new File("d:/youku/Youku Files/transcode/"+filetwo.getOriginalFilename());// 上传后的文件保存目录及名字
				
				// 将上传文件保存到相应位置
				if(file.getSize() != 0) {
					file.transferTo(imageFile);
					// 删除原文件
					String oldName = videoService.findLocalByVid(vid).getImage();
					System.out.println(oldName);
					if(oldName != null && oldName.length() != 0) {
						File fileold = new File("D:\\youku\\Youku Files\\transcode\\截图\\"+oldName.substring(3, oldName.length()));
						fileold.delete();
					}
				}
				if(filetwo.getSize() != 0) {
					filetwo.transferTo(imageFiletwo);
					// 删除原文件
					String oldNametwo = videoService.findLocalByVid(vid).getLocal();
					System.out.println(oldNametwo);
					if(oldNametwo != null && oldNametwo.length() != 0) {
						File fileoldtwo = new File("D:\\youku\\Youku Files\\transcode\\"+oldNametwo);
						fileoldtwo.delete();
					}
				}
				
				// 更新图片，视频路径
				if(file.getSize() != 0) {
					Video video = new Video();
					video.setVid(vid);
					video.setImage(local);
					videoService.updateImage(video);
				}
				
				if(filetwo.getSize() != 0) {
					Video videotwo = new Video();
					videotwo.setVid(vid);
					videotwo.setLocal(localtwo);
					videoService.updateLocal(videotwo);
				}
				return "redirect:/admin/videotwo?pageNo="+pageNo;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/admin/videotwo?pageNo="+pageNo;
	}
	
	// 进去视频信息添加页面
	@RequestMapping(value="/admin/video/goadd")
	public String goaddvideo() {
		return "views/admin/video/add";
	}
	
	// 进去视频信息添加页面
	@RequestMapping(value="/admin/videotwo/goadd")
	public String goaddvideotwo() {
		return "views/admin/video/addenjoyvideo";
	}
	
	// 添加视频相关信息，然后进入添加视频与图片界面
	@RequestMapping(value="/admin/video/add", method = RequestMethod.POST)
	public String adminvideoadd(Model model,@ModelAttribute Video video) {
		videoService.add(video);
		model.addAttribute("vid", video.getVid());
		return "views/admin/video/addtwo";
	}
	
	// 添加视频相关信息，然后进入添加视频与图片界面
	@RequestMapping(value="/admin/videotwo/add", method = RequestMethod.POST)
	public String adminvideotwoadd(Model model,@ModelAttribute Video video) {
		videoService.add(video);
		model.addAttribute("vid", video.getVid());
		return "views/admin/video/addenjoyvideotwo";
	}
	
	// 管理员添加信息后添加音频
	@RequestMapping(value="/admin/video/addtwo/{vid}", method = RequestMethod.POST)
	public String adminvideoaddtwo(HttpServletRequest request,@PathVariable("vid") Integer vid) {
		// 上传:
		//直接new一个CommonsMultipartResolver
		try {
			CommonsMultipartResolver cmr = new CommonsMultipartResolver(request.getServletContext());
			cmr.setDefaultEncoding("utf-8");
			cmr.setMaxInMemorySize(40960);
			cmr.setMaxUploadSize(10485760000L);
			if (cmr.isMultipart(request)) {
				MultipartHttpServletRequest multipartRequest = cmr.resolveMultipart(request);
				// 获取图片，视频路径
				MultipartFile file = multipartRequest.getFile("image");// 与页面input的name相同
				String local = "截图/"+file.getOriginalFilename();
				System.out.println("-----"+local);
				File imageFile = new File("d:/youku/Youku Files/transcode/截图/"+file.getOriginalFilename());// 上传后的文件保存目录及名字
				
				MultipartFile filetwo = multipartRequest.getFile("video");// 与页面input的name相同
				String localtwo = filetwo.getOriginalFilename();
				File imageFiletwo = new File("d:/youku/Youku Files/transcode/"+filetwo.getOriginalFilename());// 上传后的文件保存目录及名字
				
				// 将上传文件保存到相应位置
				if(file.getSize() != 0) {
					file.transferTo(imageFile);
				}
				if(filetwo.getSize() != 0) {
					filetwo.transferTo(imageFiletwo);
				}
				
				// 更新图片，视频路径
				if(file.getSize() != 0) {
					Video video = new Video();
					video.setVid(vid);
					video.setImage(local);
					videoService.updateImage(video);
				}
				
				if(filetwo.getSize() != 0) {
					Video videotwo = new Video();
					videotwo.setVid(vid);
					videotwo.setLocal(localtwo);
					videoService.updateLocal(videotwo);
				}
				return "redirect:/admin/video";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/admin/video";
	}
	
	// 管理员添加信息后添加音频
	@RequestMapping(value="/admin/videotwo/addtwo/{vid}", method = RequestMethod.POST)
	public String adminvideotwoaddtwo(HttpServletRequest request,@PathVariable("vid") Integer vid) {
		// 上传:
		//直接new一个CommonsMultipartResolver
		try {
			CommonsMultipartResolver cmr = new CommonsMultipartResolver(request.getServletContext());
			cmr.setDefaultEncoding("utf-8");
			cmr.setMaxInMemorySize(40960);
			cmr.setMaxUploadSize(10485760000L);
			if (cmr.isMultipart(request)) {
				MultipartHttpServletRequest multipartRequest = cmr.resolveMultipart(request);
				// 获取图片，视频路径
				MultipartFile file = multipartRequest.getFile("image");// 与页面input的name相同
				String local = "截图/"+file.getOriginalFilename();
				System.out.println("-----"+local);
				File imageFile = new File("d:/youku/Youku Files/transcode/截图/"+file.getOriginalFilename());// 上传后的文件保存目录及名字
				
				MultipartFile filetwo = multipartRequest.getFile("video");// 与页面input的name相同
				String localtwo = filetwo.getOriginalFilename();
				File imageFiletwo = new File("d:/youku/Youku Files/transcode/"+filetwo.getOriginalFilename());// 上传后的文件保存目录及名字
				
				// 将上传文件保存到相应位置
				if(file.getSize() != 0) {
					file.transferTo(imageFile);
				}
				if(filetwo.getSize() != 0) {
					filetwo.transferTo(imageFiletwo);
				}
				
				// 更新图片，视频路径
				if(file.getSize() != 0) {
					Video video = new Video();
					video.setVid(vid);
					video.setImage(local);
					videoService.updateImage(video);
				}
				
				if(filetwo.getSize() != 0) {
					Video videotwo = new Video();
					videotwo.setVid(vid);
					videotwo.setLocal(localtwo);
					videoService.updateLocal(videotwo);
				}
				return "redirect:/admin/videotwo";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/admin/videotwo";
	}
	
	// 下面四个加载主页面
	@RequestMapping("/admin/top")
    public String top(Model model) {
		return "views/admin/top";
	}
	
	@RequestMapping("/admin/welcome")
    public String welcome(Model model) {
		return "views/admin/welcome";
	}
	
	@RequestMapping("/admin/left")
    public String left(Model model) {
		return "views/admin/left";
	}
	
	@RequestMapping("/admin/bottom")
    public String bottom(Model model) {
		return "views/admin/bottom";
	}
}
