package com.hu.entity;
/**
 * reply表的实体类
 * @author 10851
 *
 */
public class Reply {

	private Integer rid;
	private Integer disid;
	private String date;
	private String author;
	private String content;
	public Integer getRid() {
		return rid;
	}
	public void setRid(Integer rid) {
		this.rid = rid;
	}
	public Integer getDisid() {
		return disid;
	}
	public void setDisid(Integer disid) {
		this.disid = disid;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
}
