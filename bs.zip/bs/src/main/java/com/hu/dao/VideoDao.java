package com.hu.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.hu.entity.Article;
import com.hu.entity.Video;
/**
 * video的Dao
 * @author 10851
 *
 */
@Repository
public interface VideoDao {

	List<Video> list(@Param("csid") Integer csid);

	Video findByVid(@Param("vid") Integer vid);

	int findFirstVid(@Param("csid") Integer csid);

	int findLastVid(@Param("csid") Integer csid);

	Video findPrevious(@Param("vid") Integer vid, @Param("csid") Integer csid);

	Video findNext(@Param("vid") Integer vid, @Param("csid") Integer csid);

	void delete(@Param("vid") Integer vid);

	Video findLocalByVid(@Param("vid") Integer vid);

	void update(Video video);

	void updateImage(Video video);

	void updateLocal(Video videotwo);

	void add(Video video);

}
