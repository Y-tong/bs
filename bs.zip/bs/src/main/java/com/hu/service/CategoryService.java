package com.hu.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.hu.dao.CategoryDao;
import com.hu.entity.Category;

@Service
public class CategoryService {

	@Resource
	private CategoryDao categoryDao;

	public List<Category> getCategorys() {
		List<Category> categorys = categoryDao.getCategorys();
		if(categorys != null) {
			return categorys;
		}else {
			return null;
		}
		
	}
	
}
