package com.hu.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.hu.entity.Reply;
/**
 * 回复的Dao
 * @author 10851
 *
 */
@Repository
public interface ReplyDao {

	List<Reply> list(@Param("disid") Integer disid);

	void reply(Reply reply);

	void delete(@Param("rid") Integer rid);

	void deleteByDisid(@Param("disid") Integer disid);


}
