package com.hu.entity;
/**
 * 管理员表的实体类
 * @author 10851
 *
 */
public class Admin {

	private Integer adminid;
	private String username;
	private String password;
	
	public Integer getAdminid() {
		return adminid;
	}
	public void setAdminid(Integer adminid) {
		this.adminid = adminid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
